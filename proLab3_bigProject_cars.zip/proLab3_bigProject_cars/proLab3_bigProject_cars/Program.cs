﻿using System;
using System.ComponentModel.Design;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Reflection;
using OfficeOpenXml.FormulaParsing.LexicalAnalysis;
using System.Runtime.CompilerServices;
using System.IO;
using System.Diagnostics;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateAndTime.Workdays;

namespace CarShoppie
{
    public class Cars
    {
        public string BrandName { get; set; }
        public string ModelName { get; set; }
        public string PackageName { get; set; }
        public string[] ToolName = new string[10];
        public int ToolWeHaveNumber {get; set; }

                
    }
    
    public class User
    {

        public string username { get; set; }
        public string password { get; set; }
        public string nameSurname { get; set; }
        public string email { get; set; }
        public string phone { get; set; }

        public User(string username, string password, string nameSurname, string email, string phone)
        {
            this.username = username;
            this.password = password;
            this.nameSurname = nameSurname;
            this.email = email;
            this.phone = phone;
        }

    }

    public class Admin : User
    {
        public string usertype = "admin";

        public Admin(string username, string password, string nameSurname, string email, string phone, string usertype) : base(username,password,nameSurname,email,phone)
        {
            this.usertype = usertype;
        }

    }

    public class Customer : User
    {
        public string usertype = "customer";

        public Customer(string username, string password, string nameSurname, string email, string phone, string usertype) : base(username, password, nameSurname, email, phone)
        {
            this.usertype = usertype;
        }

    }

    public class Dealer : User
    {
        public string usertype = "dealer";

        public Dealer(string username, string password, string nameSurname, string email, string phone, string usertype) : base(username, password, nameSurname, email, phone)
        {
            this.usertype = usertype;
        }

    }




    class Program
    {
        static void list_cars()
        {
            Console.Clear();

            string carDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData";

            string[] carList = Directory.GetDirectories(carDataPath).Select(Path.GetFileName).ToArray();


            int carNumber = 0;
            string theCarName = "";
            string carNamePath = "";

            for (int carListCounter = 0; carListCounter < carList.Length; carListCounter++)
            {
                string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                for (int packageCounter = 0; packageCounter < packageList.Length; packageCounter++)
                {
                    carNumber++;



                    carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                    using (StreamReader carName = new StreamReader(carNamePath))
                    {
                        theCarName = carName.ReadToEnd();
                    }

                    Console.WriteLine(carNumber + " - " + theCarName);
                }

            }
        }

        static void CopyDirectory(string sourceDir, string destDir)
        {
            Directory.CreateDirectory(destDir);

            foreach (string file in Directory.GetFiles(sourceDir))
            {
                string destFile = Path.Combine(destDir, Path.GetFileName(file));
                File.Copy(file, destFile, true);
            }

            foreach (string subDir in Directory.GetDirectories(sourceDir))
            {
                string destSubDir = Path.Combine(destDir, Path.GetFileName(subDir));
                CopyDirectory(subDir, destSubDir);
            }
        }


        static void refreshStock()
        {
            string userDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData";


            string[] users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();
            int howManyDealer = 0;

            for(int usersCounter = 0; usersCounter < users.Length; usersCounter++)
            {
                using (StreamReader usertypeREAD = new StreamReader(userDataPath + "\\" + users[usersCounter] + "\\usertype.txt"))
                {
                    string usertype = usertypeREAD.ReadToEnd();
                    if (usertype == "dealer")
                        howManyDealer++;
                }
            }

            string[] dealers = new string[howManyDealer];
            int trash = 0;

            for (int usersCounter = 0; usersCounter < users.Length; usersCounter++)
            {
                using (StreamReader usertypeREAD = new StreamReader(userDataPath + "\\" + users[usersCounter] + "\\usertype.txt"))
                {
                    string usertype = usertypeREAD.ReadToEnd();
                    if (usertype == "dealer")
                    {
                        dealers[trash] = users[usersCounter];
                        trash++;
                    }
                }
            }

            for (int dealercounter=0; dealercounter < howManyDealer; dealercounter++)
            {
                string sourcefilespath = userDataPath + "\\" + dealers[dealercounter] + "\\cars";
                string nextPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData";

                CopyDirectory(sourcefilespath, nextPath);

            }


        }




        static void Main(string[] args)
        {
            string userDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData";
            string carDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData";

            firstScreen:

            refreshStock();

            Console.WriteLine("WELCOME...");
            Console.WriteLine("PLEASE LOGİN OR SIGN UP...");
            Console.WriteLine("PRESS 1 - LOGIN");
            Console.WriteLine("PRESS 2 - SIGN UP");
            Console.WriteLine("PRESS 8 - EXIT");
            Console.Write("MAKE YOUR CHOICE : ");
            int startingchoice;

            while(!(int.TryParse(Console.ReadLine(), out startingchoice) && (startingchoice==1 || startingchoice==2 || startingchoice==8)))
            {
                Console.Clear();
                Console.WriteLine("INVALID CHOICE... PLEASE TRY AGAIN...");
                Console.WriteLine("PRESS 1 - LOGIN");
                Console.WriteLine("PRESS 2 - SIGN UP");
                Console.WriteLine("PRESS 8 - EXIT");
                Console.WriteLine("MAKE YOUR CHOICE : ");
            }

            if(startingchoice==8) 
            {
                Console.WriteLine("SEE YOU AGAIN...");
            }
            else if (startingchoice==1)  // ---------------------------------------------------------------------------------- LOGIN PARTS -----------------
            {
                string[] users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();

                Console.Clear();
                Console.WriteLine("LOGIN PAGE");
                Console.Write("Username : ");
                string username = Console.ReadLine().ToString();

                bool userHave = false;
                string password;
                string usertype;

                for (int usersCounter = 0; usersCounter < users.Length; usersCounter++)
                {
                    if (users[usersCounter] == username)
                    {
                        Console.Clear();
                        Console.WriteLine("Welcome, " + username);
                        userHave = true;
                        break;
                    }

                }

                if (userHave)
                {
                    getpassword:

                    Console.Write("Please type your password : ");
                    password = Console.ReadLine();

                    string passwordOfTypedUsername = File.ReadAllText(userDataPath + "\\" + username + "\\password.txt");

                    if(password == passwordOfTypedUsername)
                    {
                        Console.Clear();

                        string userNameSurname = File.ReadAllText(userDataPath + "\\" + username + "\\name_surname.txt");
                        usertype = File.ReadAllText(userDataPath + "\\" + username + "\\usertype.txt");

                        Console.WriteLine("Welcome, " + userNameSurname + " (" + usertype + ")");
                        Console.WriteLine("Press any key to continue...");
                        Console.ReadLine();


                        if (usertype == "admin")
                        {
                            mainmenu:
                            refreshStock();
                            Console.Clear();
                            Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");

                            Console.WriteLine("Type 1 - Show All Cars and Stocks");    
                            Console.WriteLine("Type 2 - Show All Users");

                            Console.Write("Please make your choice : ");
                            int loginAdminCarsOrUsers;

                            while(!(int.TryParse(Console.ReadLine(), out loginAdminCarsOrUsers) && (loginAdminCarsOrUsers==1 || loginAdminCarsOrUsers==2)))
                            {
                                Console.Clear();
                                Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");

                                Console.WriteLine("INVALID CHOICE... PLEASE TRY AGAIN...");

                                Console.WriteLine("Type 1 - Show All Cars and Stocks");
                                Console.WriteLine("Type 2 - Show All Users");
                            }

                            choosecar:
                            refreshStock();

                            if (loginAdminCarsOrUsers == 1)
                            {
                                Console.Clear();

                                string[] carList = Directory.GetDirectories(carDataPath).Select(Path.GetFileName).ToArray();


                                int carNumber = 0;
                                string theCarName = "";
                                string carNamePath = "";

                                for (int carListCounter=0; carListCounter < carList.Length; carListCounter++)
                                {
                                    string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                                    for(int packageCounter=0; packageCounter < packageList.Length; packageCounter++)
                                    {
                                        carNumber++;

                                        

                                        carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                                        using (StreamReader carName = new StreamReader(carNamePath))
                                        {
                                            theCarName = carName.ReadToEnd();
                                        }

                                        Console.WriteLine(carNumber + " - " + theCarName);
                                    }

                                }

                                

                                carNumber = 0;

                                Console.Write("Please choose the car to list its tools : ");
                                int kacıncıaraba = Convert.ToInt32(Console.ReadLine());
                                string secilmisarabaPath = "";
                                string secilmisarabaParcaPath = "";

                                for (int carListCounter = 0; carListCounter < carList.Length; carListCounter++)
                                {
                                    string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                                    for (int packageCounter = 0; packageCounter < packageList.Length; packageCounter++)
                                    {
                                        carNumber++;



                                        carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                                        using (StreamReader carName = new StreamReader(carNamePath))
                                        {
                                            theCarName = carName.ReadToEnd();
                                        }


                                        if (carNumber == kacıncıaraba)
                                        {
                                            secilmisarabaPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter];
                                            
                                            string[] arabanınparcalar = Directory.GetDirectories(secilmisarabaPath).Select(Path.GetFileName).ToArray();
                                                                                        

                                            string[] arabanınParcalari = Directory.GetDirectories(secilmisarabaPath).Select(Path.GetFileName).ToArray();

                                            Console.Clear();

                                            Console.WriteLine(theCarName + " TOOL LIST\n");
                                            string theParcaStock = "";

                                            for (int parcaCounter=0; parcaCounter < arabanınParcalari.Length; parcaCounter++)
                                            {
                                                string secilmisarabaStockPath = secilmisarabaPath + "\\" + arabanınparcalar[parcaCounter] + "\\stock.txt";



                                                using (StreamReader stock = new StreamReader(secilmisarabaStockPath))
                                                {
                                                    theParcaStock = stock.ReadToEnd();

                                                    if (theParcaStock.Length == 0)
                                                        theParcaStock = "0";
                                                }

                                                Console.WriteLine(arabanınParcalari[parcaCounter] + " - stock : " + theParcaStock);

                                            }



                                            adminbacktomenuchoice:
                                            Console.WriteLine("Type 1 to car list menu, Type 2 to main menu,");
                                            Console.Write("Type 3 to EXIT : ");
                                            int backtomenu = Convert.ToInt32(Console.ReadLine());

                                            if(backtomenu == 1)
                                            {
                                                Console.Clear();
                                                goto choosecar;
                                            }
                                            else if(backtomenu == 2)
                                            {
                                                Console.Clear();
                                                goto mainmenu;
                                            }
                                            else if(backtomenu == 3)
                                            {
                                                Console.Clear();
                                                goto firstScreen;
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Invalid Choice...");
                                                goto adminbacktomenuchoice;
                                            }

                                            


                                        }
                                    }
                                } // admin cars list end
                            }
                            else if (loginAdminCarsOrUsers == 2)
                            {
                                Console.Clear();
                                Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");
                                Console.WriteLine("USER LIST");
                                Console.WriteLine();
                                
                                for (int i = 0; i<users.Length; i++)
                                {
                                    string readusertypepath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData\\" + users[i] + "\\usertype.txt";
                                    string usertypereaded = "";

                                    using (StreamReader usertyperead = new StreamReader(readusertypepath))
                                    {
                                        usertypereaded = usertyperead.ReadToEnd();

                                    }
       

                                    Console.Write(usertypereaded + " " + users[i]);

                                    if (users[i] == username)
                                        Console.Write(" (YOU)");

                                    Console.WriteLine();


                                }


                                areyoueditusers:
                                Console.WriteLine("Press 3 to edit users");
                                Console.WriteLine("Press 7 to main menu");
                                Console.WriteLine("Press 9 to EXIT");
                                Console.Write("Make your choice : ");

                                int areyoueditusers = Convert.ToInt32(Console.ReadLine());

                                if (areyoueditusers == 3)
                                {
                                    Console.Clear();
                                    Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");
                                    Console.WriteLine("USER EDIT (YOU CAN NOT EDIT ADMINS)");
                                    Console.WriteLine();

                                    int nonFuncCounter = 0;
                                    for (int i = 0; i < users.Length; i++)
                                    {
                                        string readusertypepath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData\\" + users[i] + "\\usertype.txt";
                                        string usertypereaded = "";

                                        using (StreamReader usertyperead = new StreamReader(readusertypepath))
                                        {
                                            usertypereaded = usertyperead.ReadToEnd();

                                        }

                                        nonFuncCounter++;

                                        if (usertypereaded != "admin")
                                        {
                                            Console.WriteLine(nonFuncCounter + " " + usertypereaded + " " + users[i]);
                                        }
                                        else
                                            nonFuncCounter--;

                                    }

                                    Console.WriteLine();
                                    Console.Write("Write the username : ");
                                    string usernameGetToEdit = Console.ReadLine().ToString().ToLower();

                                    string dataGetwithUsernamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData\\" + usernameGetToEdit;

                                    string[] dataFilesintheUser = Directory.GetFiles(dataGetwithUsernamePath).Select(Path.GetFileName).ToArray();


                                    for (int i = 0; i < dataFilesintheUser.Length; i++)
                                    {
                                        using (StreamReader ReadedUserDataFile = new StreamReader(dataGetwithUsernamePath + "\\" + dataFilesintheUser[i]))
                                        {
                                            Console.WriteLine(ReadedUserDataFile.ReadToEnd());
                                        }
                                    }


                                    Console.Write("Type 000 (zero zero zero) to delete the user : ");
                                    string deleteCommand = Console.ReadLine().ToString();

                                    if(deleteCommand == "000")
                                    {
                                        System.IO.DirectoryInfo di = new DirectoryInfo(dataGetwithUsernamePath);

                                        foreach (FileInfo file in di.GetFiles())
                                        {
                                            file.Delete();
                                        }
                                        foreach (DirectoryInfo dir in di.GetDirectories())
                                        {
                                            dir.Delete(true);
                                        }

                                        Directory.Delete(dataGetwithUsernamePath);

                                        Console.WriteLine("user was deleted...");

                                        System.Threading.Thread.Sleep(2000);

                                        users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();

                                        goto mainmenu;
                                    }












                                }
                                else if(areyoueditusers == 7)
                                {
                                    goto mainmenu;
                                }
                                else if(areyoueditusers == 9)
                                {
                                    Console.Clear();
                                    Console.WriteLine("See you again...");
                                }
                                else
                                {
                                    Console.Clear();
                                    goto areyoueditusers;
                                }

                            }
                        // ADMIN CONTROL PAGE END
                        }
                        else if (usertype == "customer")
                        {
                            Console.WriteLine("CUSTOMER CONTROL UNIT \n");


                            mainmenu:
                            refreshStock();

                            Console.WriteLine("Type 1 to list all cars or buy anything");
                            Console.WriteLine("Type 2 to delete account");
                            Console.WriteLine("Type 3 to EXIT");
                            Console.Write("Make your choice : ");
                            int customerfirstchoice = Convert.ToInt32(Console.ReadLine());


                            if(customerfirstchoice == 1)
                            {
                                choosecar:
                                refreshStock();


                                list_cars();


                                string[] carList = Directory.GetDirectories(carDataPath).Select(Path.GetFileName).ToArray();

                                string theCarName = "";
                                string carNamePath = "";
                                int carNumber = 0;

                                Console.Write("Please choose the car to list its tools : ");
                                int whichCar = Convert.ToInt32(Console.ReadLine());
                                string choosedCarPath = "";

                                for (int carListCounter = 0; carListCounter < carList.Length; carListCounter++)
                                {
                                    string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                                    for (int packageCounter = 0; packageCounter < packageList.Length; packageCounter++)
                                    {
                                        carNumber++;


                                        carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                                        using (StreamReader carName = new StreamReader(carNamePath))
                                        {
                                            theCarName = carName.ReadToEnd();
                                        }


                                        if (carNumber == whichCar)
                                        {
                                            choosedCarPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter];


                                            string[] toolsOfTheCar = Directory.GetDirectories(choosedCarPath).Select(Path.GetFileName).ToArray();

                                            Console.Clear();

                                            Console.WriteLine(theCarName + " TOOL LIST\n");
                                            string theToolStock = "";

                                            for (int toolCounter = 0; toolCounter < toolsOfTheCar.Length; toolCounter++)
                                            {
                                                string choosedCarStockPath = choosedCarPath + "\\" + toolsOfTheCar[toolCounter] + "\\stock.txt";



                                                using (StreamReader stock = new StreamReader(choosedCarStockPath))
                                                {
                                                    theToolStock = stock.ReadToEnd();

                                                    if (theToolStock.Length == 0)
                                                        theToolStock = "0";
                                                }

                                                Console.WriteLine(toolsOfTheCar[toolCounter] + " - stock : " + theToolStock);

                                            }



                                            backtomenuchoice:
                                            refreshStock();

                                            Console.WriteLine("Type 1 to car list menu, Type 2 to main menu,");
                                            Console.Write("Type 3 to EXIT : ");
                                            int backtomenu = Convert.ToInt32(Console.ReadLine());

                                            if (backtomenu == 1)
                                            {
                                                Console.Clear();
                                                goto choosecar;
                                            }
                                            else if (backtomenu == 2)
                                            {
                                                Console.Clear();
                                                goto mainmenu;
                                            }
                                            else if (backtomenu == 3)
                                            {
                                                Console.Clear();
                                                goto firstScreen;
                                            }
                                            else
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Invalid Choice...");
                                                goto backtomenuchoice;
                                            }




                                        }
                                    }
                                }



                            } // customer first choice if

                            else if (customerfirstchoice == 2)
                            {
                                Console.Clear();
                                Console.WriteLine("CUSTOMER ACCOUNT DELETE");
                                Console.WriteLine();
                                Console.WriteLine("Your account will be deleted...");
                                Console.WriteLine("Are you sure ?");
                                Console.WriteLine("If you want to delete your account, please type 000 (zero zero zero)");






                            }

                            else if (customerfirstchoice == 3)
                            {
                                Console.Clear();
                                Console.WriteLine("See you again");
                            }
                            else
                            {
                                Console.Clear();
                                goto mainmenu;
                            }



                        }
                        else if (usertype == "dealer")
                        {
                            mainmenu:
                            refreshStock();
                            File.Delete(carDataPath + "\\newDealer.txt");
                            Console.WriteLine("DEALER CONTROL UNIT \n");

                            if(File.Exists(userDataPath + "\\" + username + "\\cars\\newDealer.txt"))
                            {
                                Console.Clear();

                                Console.WriteLine("Hellooo, looks like you are a new dealer.");
                                Console.WriteLine("Welcome to the club :)");
                                Console.WriteLine("You have to add a car...");
                                Console.WriteLine();

                                newdealercaradd:

                                Console.Write("Car brand : ");
                                string newcarbrand = Console.ReadLine();

                                Console.Write("Car model : ");
                                string newcarmodel = Console.ReadLine();

                                Console.Write("Car package name 1 : ");
                                string newcarpack1 = Console.ReadLine();

                                Console.Write("Car package name 2 : ");
                                string newcarpack2 = Console.ReadLine();


                                string[] newcarbrandwords = newcarbrand.Split(' ');
                                if (newcarbrandwords.Length > 1)
                                {
                                    newcarbrand = "";

                                    for (int i = 0; i < newcarbrandwords.Length; i++)
                                    {
                                        newcarbrand += newcarbrandwords[i];

                                        if (i < newcarbrandwords.Length - 1)
                                        {
                                            newcarbrand += "_";
                                        }
                                    }
                                }

                                string[] newcarmodelwords = newcarmodel.Split(' ');
                                if (newcarmodelwords.Length > 1)
                                {
                                    newcarmodel = "";

                                    for (int i = 0; i < newcarmodelwords.Length; i++)
                                    {
                                        newcarmodel += newcarmodelwords[i];
                                    }
                                }

                                string[] newcarpack1words = newcarpack1.Split(' ');
                                if (newcarbrandwords.Length > 1)
                                {
                                    newcarpack1 = "";

                                    for (int i = 0; i < newcarpack1words.Length; i++)
                                    {
                                        newcarbrand += newcarpack1words[i];
                                    }
                                }

                                string[] newcarpack2words = newcarpack2.Split(' ');
                                if (newcarpack2words.Length > 1)
                                {
                                    newcarpack2 = "";

                                    for (int i = 0; i < newcarpack2words.Length; i++)
                                    {
                                        newcarpack2 += newcarpack2words[i];
                                    }
                                }

                                Console.WriteLine(newcarbrand);
                                Console.WriteLine(newcarmodel);
                                Console.WriteLine(newcarpack1);
                                Console.WriteLine(newcarpack2);

                                string newbrandlower = newcarbrand.ToLower();
                                string newmodellower = newcarmodel.ToLower();
                                string newpack1lower = newcarpack1.ToLower();
                                string newpack2lower = newcarpack2.ToLower();



                                bool uniquecar = true;


                                if (Directory.Exists(carDataPath + "\\" + newbrandlower + "_" + newmodellower))
                                    uniquecar = false;


                                if(uniquecar)
                                {
                                    Directory.CreateDirectory(userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower);
                                    Directory.CreateDirectory(userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack1lower);
                                    Directory.CreateDirectory(userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack2lower);

                                    string templatecardata = Directory.GetCurrentDirectory() + "\\theDatabase\\templateFiles_selling";

                                    CopyDirectory(templatecardata, userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack1lower);
                                    CopyDirectory(templatecardata, userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack2lower);


                                    using (StreamWriter brandmodelpack1 = new StreamWriter(userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack1lower + "\\car_brand_model_name.txt"))
                                    {
                                        brandmodelpack1.Write(newcarbrand + " " + newcarmodel + " " + newcarpack1);
                                    }

                                    using (StreamWriter brandmodelpack2 = new StreamWriter(userDataPath + "\\" + username + "\\cars\\" + newbrandlower + "_" + newmodellower + "\\" + newpack2lower + "\\car_brand_model_name.txt"))
                                    {
                                        brandmodelpack2.Write(newcarbrand + " " + newcarmodel + " " + newcarpack2);
                                    }




                                    File.Delete(userDataPath + "\\" + username + "\\cars\\newDealer.txt");


                                    Console.WriteLine("Your first car was added. Stocks are 0 (zero).");
                                    Console.WriteLine("You can add them later...");


                                }
                                else
                                {
                                    Console.Clear();
                                    Console.WriteLine("Sorry, but we already have this car.");
                                    Console.WriteLine("Please add another car...");
                                    Console.WriteLine();
                                    goto newdealercaradd;
                                }






                            }













                        }

                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid password...");
                        Console.WriteLine();
                        goto getpassword;
                    }

                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("User was not found...");
                    Console.WriteLine("Please try again or sign up...");
                }






            }
            else if (startingchoice==2)  // ---------------------------------------------------------------------------------- SIGN UP PARTS -----------------
            {
                Console.Clear();
                Console.WriteLine("SIGNUP PAGE \n");
                Console.WriteLine("Username rules...");
                Console.WriteLine("Limitted with 5-20 character"); 
                Console.WriteLine("You can use numerical or alphabetical characters"); 
                Console.WriteLine("You can not use special characters...\n");
                Console.WriteLine();
                refreshStock();

                usernameget:

                Console.Write("Type a Username : ");

                string newUsername = Console.ReadLine();
                bool usernameAlphaNumericControl  = true;

                foreach (char c in newUsername)
                {
                    if (!char.IsLetterOrDigit(c))
                    {
                        usernameAlphaNumericControl = false;
                    }

                }

                bool newUserUnıqueControl = true;
                string[] users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();

                for (int usersCounter = 0; usersCounter < users.Length; usersCounter++)
                {
                    if (users[usersCounter] == newUsername)
                    {
                        newUserUnıqueControl = false;
                    }
                }


                if (newUserUnıqueControl)
                {
                    if (usernameAlphaNumericControl && newUsername.Length >= 5 && newUsername.Length <= 20 && char.IsLetter(newUsername[0]))
                    {
                        Console.Clear();
                        Console.WriteLine("SIGNUP PAGE \n");
                        Console.WriteLine("Password rules...");
                        Console.WriteLine("Limitted with 8-20 character");
                        Console.WriteLine("You must use at least 1 number,");
                        Console.WriteLine("at least 1 uppercase letter, at least 1 lowercase letter,");
                        Console.WriteLine("at least 1 special character from !@#$%&*_+");
                        Console.WriteLine("You can not use space...\n");
                        Console.WriteLine();

                        passwordget:

                        Console.WriteLine("Your Username : " + newUsername);
                        Console.Write("Please type your Password : ");
                        string newUserPassword = Console.ReadLine();

                        bool passwordRule8_20 = false;
                        bool passwordRuleLeast1Num = false;
                        bool passwordRuleLeast1upper = false;
                        bool passwordRuleLeast1lower = false;
                        bool passwordRuleSpecial = false;
                        bool passwordRuleNoSpace = false;

                        string specialCharacters = "!@#$%&*_+";

                        if (newUserPassword.Length >= 8 && newUserPassword.Length <= 20)
                            passwordRule8_20 = true;

                        for (int passwordStringCounter = 0; passwordStringCounter < newUserPassword.Length; passwordStringCounter++)
                        {
                            if (char.IsDigit(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1Num = true;

                            if (char.IsUpper(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1upper = true;

                            if (char.IsLower(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1lower = true;

                            for (int specialstringCounter = 0; specialstringCounter < specialCharacters.Length; specialstringCounter++)
                            {
                                if (newUserPassword[passwordStringCounter] == specialCharacters[specialstringCounter])
                                    passwordRuleSpecial = true;
                            }

                            if (!newUserPassword.Contains(" "))
                                passwordRuleNoSpace = true;

                        }


                        if (passwordRule8_20 && passwordRuleLeast1Num && passwordRuleLeast1upper && passwordRuleLeast1lower && passwordRuleSpecial && passwordRuleNoSpace)
                        {
                            Console.Clear();
                            Console.WriteLine("SIGNUP PAGE \n");
                            Console.WriteLine("Name Surname rules...");
                            Console.WriteLine("You can not use special characters...\n");
                            Console.WriteLine();

                            namesurnameget:

                            Console.WriteLine("Your Username : " + newUsername);
                            Console.WriteLine("Your Username : " + newUserPassword);
                            Console.Write("Please type your Name and Surname : ");

                            string newNameSurname = Console.ReadLine();

                            bool newNameSurnameIsOK = true;

                            for (int nameSurCount=0; nameSurCount<newNameSurname.Length; nameSurCount++)
                            {
                                if (!char.IsLetter(newNameSurname[nameSurCount]))
                                {
                                    if (!(newNameSurname[nameSurCount] == ' '))
                                        newNameSurnameIsOK = false;
                                }
                                    
                            }

                            if (newNameSurnameIsOK)
                            {
                                Console.Clear();
                                Console.WriteLine("SIGNUP PAGE \n");
                                Console.WriteLine("E-Mail rules...");
                                Console.WriteLine("The first character can not be special character...");
                                Console.WriteLine("Your e-mail must contain the character-@...\n");
                                Console.WriteLine();

                                emailget:

                                Console.WriteLine("Your Username : " + newUsername);
                                Console.WriteLine("Your Password : " + newUserPassword);
                                Console.WriteLine("Your Name Surname : " + newNameSurname);
                                Console.Write("Please type your E-Mail : ");

                                string newEmail = Console.ReadLine();

                                bool emailFirstCharLetter = false;
                                bool emailHaveAt = false;

                                if (char.IsLetter(newEmail[0]))
                                    emailFirstCharLetter = true;

                                for (int emailStrCount=0; emailStrCount<newEmail.Length; emailStrCount++)
                                {
                                    if (newEmail[emailStrCount] == '@')
                                        emailHaveAt = true;
                                }

                                if (emailFirstCharLetter && emailHaveAt)
                                {
                                    Console.Clear();
                                    Console.WriteLine("SIGNUP PAGE \n");
                                    Console.WriteLine("Phone Number rules...");
                                    Console.WriteLine("The number must contain only numbers...");
                                    Console.WriteLine("The must type your number XXX-XXX-XXXX format...\n");
                                    Console.WriteLine();

                                    phoneget:

                                    Console.WriteLine("Your Username : " + newUsername);
                                    Console.WriteLine("Your Password : " + newUserPassword);
                                    Console.WriteLine("Your Name Surname : " + newNameSurname);
                                    Console.WriteLine("Your E-Mail : " + newEmail);
                                    Console.Write("Please type your Phone Number : ");

                                    string newPhoneNumber = Console.ReadLine();

                                    bool newPhoneOnlyNumbers = true;
                                    bool newPhoneIsTrueFormat = true;

                                    for (int newPhoneCounter=0; newPhoneCounter<newPhoneNumber.Length; newPhoneCounter++)
                                    {
                                        if (!char.IsDigit(newPhoneNumber[newPhoneCounter]))
                                        {
                                            if (newPhoneNumber[newPhoneCounter] != '-' )
                                                newPhoneOnlyNumbers = false;
                                        }
                                    }

                                    if (newPhoneNumber.Length != 12)
                                        newPhoneIsTrueFormat = false;

                                    for (int newPhoneCounter = 0; newPhoneCounter < newPhoneNumber.Length; newPhoneCounter++)
                                    {
                                        if (newPhoneCounter == 3 || newPhoneCounter == 7)
                                        {
                                            if (newPhoneNumber[newPhoneCounter] != '-')
                                                newPhoneIsTrueFormat = false;
                                        }
                                        else
                                        {
                                            if (!char.IsDigit(newPhoneNumber[newPhoneCounter]))
                                                newPhoneIsTrueFormat = false;
                                        }

                                    }


                                    if (newPhoneOnlyNumbers && newPhoneIsTrueFormat)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("SIGNUP PAGE \n");

                                        typeget:
                                        Console.WriteLine("Finally, choose your user type...");
                                        Console.WriteLine("Type 1 - Admin");
                                        Console.WriteLine("Type 2 - Customer");
                                        Console.WriteLine("Type 3 - Dealer\n");

                                        
                                        Console.Write("Please make your choice : ");

                                        

                                        int newUsertypget = Convert.ToInt32(Console.ReadLine());
                                        string newUserType = "";
                                        bool usertypetrue = true;
                                        string newUserPath = "";

                                        if (newUsertypget == 1)
                                        {
                                            newUserType = "admin";
                                            
                                        }
                                        else if (newUsertypget == 2)
                                        {
                                            newUserType = "customer";
                                        }
                                        else if (newUsertypget == 3)
                                        {
                                            newUserType = "dealer";
                                        }
                                        else
                                        {
                                            Console.Clear();
                                            usertypetrue = false;
                                            goto typeget;
                                        }


                                        if (usertypetrue)
                                        {
                                            Console.Clear();
                                            newUserPath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData\\" + newUsername;


                                            Directory.CreateDirectory(newUserPath);


                                            string[] newUserDataFiles = new string[6];

                                            newUserDataFiles[0] = newUserPath + "\\username.txt";
                                            newUserDataFiles[1] = newUserPath + "\\password.txt";
                                            newUserDataFiles[2] = newUserPath + "\\name_surname.txt";
                                            newUserDataFiles[3] = newUserPath + "\\email.txt";
                                            newUserDataFiles[4] = newUserPath + "\\phone.txt";
                                            newUserDataFiles[5] = newUserPath + "\\usertype.txt";


                                            if(newUserType == "customer")
                                            {
                                                Directory.CreateDirectory(newUserPath + "\\cart");                                                
                                            }
                                            else if(newUserType == "dealer")
                                            {
                                                Directory.CreateDirectory(newUserPath + "\\carts");
                                                Directory.CreateDirectory(newUserPath + "\\cars");
                                                File.Create(newUserPath + "\\cars\\newDealer.txt");
                                            }



                                            using (StreamWriter newUsernameWrite = new StreamWriter(newUserDataFiles[0]))
                                                newUsernameWrite.Write(newUsername);

                                            using (StreamWriter newPasswordWrite = new StreamWriter(newUserDataFiles[1]))
                                                newPasswordWrite.Write(newUserPassword);

                                            using (StreamWriter newNameSurnameWrite = new StreamWriter(newUserDataFiles[2]))
                                                newNameSurnameWrite.Write(newNameSurname);

                                            using (StreamWriter newEmailWrite = new StreamWriter(newUserDataFiles[3]))
                                                newEmailWrite.Write(newEmail);

                                            using (StreamWriter newPhoneWrite = new StreamWriter(newUserDataFiles[4]))
                                                newPhoneWrite.Write(newPhoneNumber);

                                            using (StreamWriter newUsertypeWrite = new StreamWriter(newUserDataFiles[5]))
                                                newUsertypeWrite.Write(newUserType);



                                            Console.WriteLine("Username : " + newUsername);
                                            Console.WriteLine("Password : " + newUserPassword);
                                            Console.WriteLine("Name Sur : " + newNameSurname);
                                            Console.WriteLine("E - Mail : " + newEmail);
                                            Console.WriteLine("Phone Nu : " + newPhoneNumber);
                                            Console.WriteLine("Usertype : " + newUserType);


                                            Console.WriteLine("NEW USER WAS CREATED...");

                                        }
                                        else // user type control else
                                        { 
                                            Console.Clear();
                                            Console.WriteLine("invalid user type choose...");
                                            goto typeget;
                                        }

                                    }
                                    else // phone number control else
                                    {
                                        Console.Clear();
                                        Console.WriteLine("invalid phone number...");
                                        goto phoneget;
                                    }

                                }
                                else  // email control else
                                {
                                    Console.Clear();
                                    Console.WriteLine("invalid email...");
                                    goto emailget;
                                }

                            }
                            else  // name surname control else
                            {
                                Console.Clear();
                                Console.WriteLine("invalid name surname...");
                                goto namesurnameget;
                            }

                        }
                        else  // password control else
                        {
                            Console.Clear();
                            Console.WriteLine("invalid password...");
                            goto passwordget;
                        }

                    }
                    else  // username control else
                    {
                        Console.Clear();
                        Console.WriteLine("invalid username...");
                        goto usernameget;
                    }

                }
                else // username unique control else
                {
                    Console.Clear();
                    Console.WriteLine("The username is already using. Please try again...");
                    goto usernameget;
                }

            }
        }
    }
}
